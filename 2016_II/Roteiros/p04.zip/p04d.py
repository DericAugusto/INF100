# Este programa calcula o dia e mês do domingo de páscoa entre os anos 1582 e 2499

ano = int( input("Digite um ano (1582 a 2499): "))
if ano < 1582 or ano > 2499:
    print( ano, "está fora do intervalo previsto")
elif ano < 1700:
    X = 22
    Y = 2
elif ano < 1800:
    X = 23
    Y = 3
elif ano < 1900:
    X = 23
    Y = 4
elif ano < 2100:
    X = 24
    Y = 5
elif ano < 2200:
    X = 24
    Y = 6
elif ano < 2300:
    X = 25
    Y = 0
elif ano < 2400:
    X = 26
    Y = 1
else:
    X = 25
    Y = 1

if 1582 <= ano <= 2499:
    a = ano % 19
    b = ano % 4
    c = ano % 7
    d = (19 * a + X) % 30
    e = (2 * b + 4 * c + 6 * d + Y) % 7

    P = 22 + d + e
    P1 = d + e - 9
    P2 = P1 - 7
    if P <= 31:
        print("Em", ano, "a Páscoa foi ou será em", P, "de Março")
    elif P1 <= 25:
        print("Em", ano, "a Páscoa foi ou será em", P1, "de Abril")
    else:
        print("Em", ano, "a Páscoa foi ou será em", P2, "de Abril")
