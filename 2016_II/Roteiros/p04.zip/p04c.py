# Este programa calcula o dia e mês do domingo de páscoa entre os anos 1582 e 2499

ano = int( input("Digite um ano (1582 a 2499): "))
if 1582 <= ano <= 1699:
    X = 22
    Y = 2
elif 1700 <= ano <= 1799:
    X = 23
    Y = 3
elif 1800 <= ano <= 1899:
    X = 23
    Y = 4
elif 1900 <= ano <= 2099:
    X = 24
    Y = 5
elif 2100 <= ano <= 2199:
    X = 24
    Y = 6
elif 2200 <= ano <= 2299:
    X = 25
    Y = 0
elif 2300 <= ano <= 2399:
    X = 26
    Y = 1
elif 2400 <= ano <= 2499:
    X = 25
    Y = 1
else:
    X = 0
    Y = 0

if X+Y > 0:
    a = ano % 19
    b = ano % 4
    c = ano % 7
    d = (19 * a + X) % 30
    e = (2 * b + 4 * c + 6 * d + Y) % 7

    P = 22 + d + e
    if P <= 31:
        print("Em", ano, "a Páscoa foi ou será em", P, "de Março")
    else:
        P1 = d + e - 9
        if P1 <= 25:
            print("Em", ano, "a Páscoa foi ou será em", P1, "de Abril")
        else:
            P2 = P1 - 7
            print("Em", ano, "a Páscoa foi ou será em", P2, "de Abril")
else:
    print( ano, "está fora do intervalo previsto")
