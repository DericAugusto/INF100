import numpy as np

# Esta função é semelhante à mostrada no slide 17 da Aula 9,
# mas só deve aceitar valores INTEIROS > 0.
def leiaIntPositivo( msg ):
    while True:
        vlr = int( input( msg ))
        if vlr <= 0:
            print('Valor deve ser maior que zero.')
        else: break
    return vlr

# Esta função deve criar e retornar uma matriz m x n de valores
# reais x uniformemente distribuídos tais que a <= x < b, ou seja,
# dentro do intervalo aberto [a,b).
def criaMatrizFloat( m, n, a, b ):
    return np.random.uniform( a, b, (m, n) )

# Esta função deve escrever a matriz M na tela assumindo com formatação fmt
# Dica: veja exemplos da última página do Guia Rápido de Python
def escreveMatriz( M, fmt ):
    m, n = M.shape  # Obter o número de linhas e colunas de M
    for i in range(0, m):
        for j in range(0, n):
            print( fmt % M[i][j], end='')
        print()

# Esta função deve retornar o maior valor contido na matriz M
def maiorValor( M ):
    maior = M[0][0]
    for i in range(0, len( M )):
        for x in M[i]:
            if x > maior: maior = x
    return maior
    # Se M for matriz do numpy, pode-se fazer:
    # return np.max( M )

###--------------------------------------------------------
### O programa não deve ser alterado deste ponto em diante!
###--------------------------------------------------------

# Ler o valor de m
m = leiaIntPositivo('Entre com o número de linhas da matriz: ')

# Ler o valor de n
n = leiaIntPositivo('Entre com o número de colunas da matriz: ')

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# gerar matriz A: m x n de valores reais aleatórios entre 0 e 250
A = criaMatrizFloat( m, n, 0, 250 )

# Escrever a matriz A na tela
print('\nMatriz A:')
escreveMatriz( A, '%7.1f')

# Pegar o maior valor contido em A
maior = maiorValor( A )
print('\nMaior valor: %.1f' % maior)

# Escrever a matriz A normalizada na tela
A = A / maior
print('\nMatriz A normalizada:')
escreveMatriz( A, '%7.3f')
