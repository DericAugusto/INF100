import numpy as np

# Esta função é semelhante à mostrada no slide 17 da Aula 9,
# mas só deve aceitar valores INTEIROS > 0.
def leiaIntPositivo( msg ):
    while True:
        vlr = int( input( msg ))
        if vlr <= 0:
            print('Valor deve ser maior que zero.')
        else: break
    return vlr

# Esta função deve criar e retornar uma matriz m x n de valores
# inteiros aleatórios dentro do intervalo fechado [a,b].
def criaMatrizInt( m, n, a, b ):
    return np.random.randint( a, b+1, (m, n) )

# Esta função deve escrever a matriz M na tela assumindo valores
# inteiros com espaçamento (largura) 4
def escreveMatriz( M ):
    m, n = M.shape  # Obter o número de linhas e colunas de M
    for i in range(0, m):
        for j in range(0, n):
            print('%4d' % M[i][j], end='')
        print()

# Esta função deve retornar o menor valor contido na matriz M
def menorValor( M ):
    menor = M[0][0]
    for i in range(0, len( M )):
        for x in M[i]:
            if x < menor: menor = x
    return menor
    # Se M for matriz do numpy, pode-se fazer:
    # return np.min( M )

###--------------------------------------------------------
### O programa não deve ser alterado deste ponto em diante!
###--------------------------------------------------------

# Ler o valor de m
m = leiaIntPositivo('Entre com o número de linhas da matriz: ')

# Ler o valor de n
n = leiaIntPositivo('Entre com o número de colunas da matriz: ')

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# gerar matriz A: m x n de valores inteiros aleatórios entre 1 e 10
A = criaMatrizInt( m, n, 1, 10 )

# Escrever a matriz A na tela
print('\nMatriz A:')
escreveMatriz( A )

# Pegar o menor valor contido em A
menor = menorValor( A )
print('\nMenor valor:', menor)

# Mostrar posições da matriz onde ocorre o menor valor
print('\nPosições de ocorrência do valor %d:' % menor )
print('\nLinha   Coluna')
print('--------------')
for i in range(0, m):
    for j in range(0, n):
        if A[i][j] == menor:
            print('%3d%8d' % (i, j))
