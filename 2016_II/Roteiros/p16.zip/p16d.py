import numpy as np

# Esta função é semelhante à mostrada no slide 17 da Aula 9,
# mas só deve aceitar valores INTEIROS > 0.
def leiaIntPositivo( msg ):
    while True:
        vlr = int( input( msg ))
        if vlr <= 0:
            print('Valor deve ser maior que zero.')
        else: break
    return vlr

# Esta função deve criar e retornar uma matriz m x n de valores
# inteiros aleatórios dentro do intervalo fechado [a,b].
def criaMatrizInt( m, n, a, b ):
    return np.random.randint( a, b+1, (m, n) )

# Esta função deve escrever a matriz M na tela assumindo valores
# inteiros com espaçamento (largura) 5
def escreveMatriz( M ):
    m, n = M.shape  # Obter o número de linhas e colunas de M
    for i in range(0, m):
        for j in range(0, n):
            print('%5d' % M[i][j], end='')
        print()

# Compara as matrizes A e B, retornando o número de vezes que o valor
# de Aij é igual a Bij
def similaridade( A, B ):
    m, n = A.shape  # Obter o número de linhas e colunas de A
    conta = 0
    for i in range(0, m):
        for j in range(0, n):
            if A[i][j] == B[i][j]: conta = conta + 1
    return conta

###--------------------------------------------------------
### O programa não deve ser alterado deste ponto em diante!
###--------------------------------------------------------

# Ler o valor de m
m = leiaIntPositivo('Entre com o número de linhas da matriz: ')

# Ler o valor de n
n = leiaIntPositivo('Entre com o número de colunas da matriz: ')

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# gerar as matrizes A e B: m x n de valores inteiros aleatórios binários 0 ou 1
A = criaMatrizInt( m, n, 0, 1 )
B = criaMatrizInt( m, n, 0, 1 )

# Escrever as matrizes A e B na tela
print('\nMatriz A:')
escreveMatriz( A )

print('\nMatriz B:')
escreveMatriz( B )

sim = similaridade( A, B ) / (m*n)
print('\nSimilaridade entre A e B: %.4f = %.2f%%' % (sim, sim*100) )

