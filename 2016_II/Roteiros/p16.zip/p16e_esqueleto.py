# Nome do aluno:
# Matrícula:
# Data:
# (breve comentário dizendo o programa faz)

import numpy as np

# Esta função é semelhante à mostrada no slide 17 da Aula 9,
# mas só deve aceitar valores INTEIROS > 0.
def leiaIntPositivo( msg ):
    ...

# Esta função deve criar e retornar uma matriz m x n de valores
# reais x uniformemente distribuídos tais que a <= x < b, ou seja,
# dentro do intervalo aberto [a,b).
def criaMatriz( m, n, a, b ):
    ...

# Esta função deve escrever a matriz M na tela assumindo com formatação fmt
# Dica: veja exemplos da última página do Guia Rápido de Python
def escreveMatriz( M, fmt ):
    m, n = M.shape  # Obter o número de linhas e colunas de M
    ...

# Esta função deve retornar o maior valor contido no arranjo unidimensional V
def maiorValor( V ):
    ...

# Esta função deve dividir cada elemento do arranjo unidimensional V
# pelo valor escalar a.
def divide( V, a ):
    ...

###--------------------------------------------------------
### O programa não deve ser alterado deste ponto em diante!
###--------------------------------------------------------

# Ler o valor de m
m = leiaIntPositivo('Entre com o número de linhas da matriz: ')

# Ler o valor de n
n = leiaIntPositivo('Entre com o número de colunas da matriz: ')

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# gerar matriz A: m x n de valores aleatórios entre 1 e 50
A = criaMatriz( m, n, 1, 50 )

# Escrever a matriz A na tela com formatação '5.0f'
print('\nMatriz A:')
escreveMatriz( A, '%5.0f')
    
# Dividir cada elemento A[i][j] pelo maior valor de cada linha
for i in range(0, m):
    Mi = maiorValor( A[i] )
    divide( A[i], Mi )

# Escrever o resultado na tela
print('\nMatriz A normalizada por linha:')
escreveMatriz( A, '%7.3f')
