import numpy as np

# Esta função é semelhante à mostrada no slide 17 da Aula 9,
# mas só deve aceitar valores INTEIROS > 0.
def leiaIntPositivo( msg ):
    while True:
        vlr = int( input( msg ))
        if vlr <= 0:
            print('Valor deve ser maior que zero.')
        else: break
    return vlr

# Esta função deve criar e retornar uma matriz m x n de valores
# reais x uniformemente distribuídos tais que a <= x < b, ou seja,
# dentro do intervalo aberto [a,b).
def criaMatrizFloat( m, n, a, b ):
    return np.random.uniform( a, b, (m, n) )

# Esta função deve escrever a matriz M na tela assumindo com formatação fmt
# Dica: veja exemplos da última página do Guia Rápido de Python
def escreveMatriz( M, fmt ):
    m, n = M.shape  # Obter o número de linhas e colunas de M
    for i in range(0, m):
        for j in range(0, n):
            print( fmt % M[i][j], end='')
        print()

# Esta função deve retornar o maior valor contido no arranjo unidimensional V
def maiorValor( V ):
    maior = V[0]
    for x in V:
        if x > maior: maior = x
    return maior
    # Se V for matriz do numpy, pode-se fazer:
    # return np.max( V )

# Esta função deve dividir cada elemento do arranjo unidimensional V
# pelo valor escalar a.
def divide( V, a ):
    for i in range(0, len(V)):
        V[i] = V[i] / a
    # Se V for vetor do numpy, pode-se fazer:
    # V /= a

###--------------------------------------------------------
### O programa não deve ser alterado deste ponto em diante!
###--------------------------------------------------------

# Ler o valor de m
m = leiaIntPositivo('Entre com o número de linhas da matriz: ')

# Ler o valor de n
n = leiaIntPositivo('Entre com o número de colunas da matriz: ')

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# gerar matriz A: m x n de valores aleatórios entre 1 e 10
A = criaMatrizFloat( m, n, 1, 10 )

# Escrever a matriz A na tela com formatação '5.0f'
print('\nMatriz A:')
escreveMatriz( A, '%5.0f')
    
# Dividir cada elemento A[i][j] pelo maior valor de cada linha
for i in range(0, m):
    Mi = maiorValor( A[i] )
    divide( A[i], Mi )

# Escrever o resultado na tela
print('\nMatriz A normalizada por linha:')
escreveMatriz( A, '%7.3f')
