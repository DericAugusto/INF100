cs = ['edcfed',
'je!fvr!-bimvhb!bnv!{fw!bnv!bsF/:6!/hâq!-59:2!-pmvbQ!päT!.!bdjuÂ!bspujeF!-#tpuopD!.!:!fnvmpW!.!sfM!fe!sbutpH!bsbQ#!pswjm!pe!peîbsuyf!puyfU>ncmtldsrdm`rtnb`ltfk`dk`udtpqhfmhe`q`o+`c`knqmd`cns+hrdc`hdgb`cns+q`drrdlnbébnuàsrddtpqnO–		9`gmhkdcnkdunmlt`drr',
'@eobt!fiu!oj!tqffmt!fit!fspgfCmjbt!fwpe!fujix!b!utvn!tbft!zobn!xpI@obn!b!nji!mmbd!vpz!fspgfCoxpe!lmbx!obn!b!utvn!tebps!zobn!xpI*obmzE!cpC)!eojX!fiu!oj!(ojxpmC-cmhvdgsmh&mhvnkarhqdvrm`dgS	cmhvdgsmh&mhvnkarh+cmdhqexl+qdvrm`dgS	>cdmm`aqdudqnedq&xdgsdqnedA	xkerkk`amnmm`bdgssrtlrdlhsxm`lvngcm`+rdX	',
"vh!päo!-fuofnmjdbg!bsj!ft!päo-tfttfsfuoj!tvft!bsvdpsq!päo!-bubsumbn!päO/bimvhsp!ft!päo!-bjspmhobw!ft!päo!-bkfwoj!päO/ptpeopc!ê!spnb!p!-fuofjdbq!ê!spnb!P(HUM+6,3920rnhsmìqnB0'	-`sqnotrncts+`qdordncts+éqbncts+dqenrnctS	-dc`cqdu`lnb`qfdk`drr`l+`æhsrtimh`lnb`qfdk`drnâmqnl`N	-qnbm`q`cq`",
'E/bnbshpsq!pe!pimbèfcbd!p!sbdjgjsfw!fe!bèfvrtf!päO""toêcbsbQ-`qne`o`qdnârrdr`dqqdbmd+nuhtpq`ndtfdqsmd+nrrhcrhnod']

print('Textos criptografados:')
for i in range(0,len(cs)):
    print('\nTexto %d:' % (i+1))
    print('---------')
    print( cs[i] )

print()
while True:
    m = int( input('Escolha o texto que deseja descriptografar (1..%d): ' % len(cs)))
    if m > 0 and m <= len(cs): break

s = cs[m-1]
s2 = ''

#-------------------------------------------------------------------
# SEU CÓDIGO DEVE INICIAR ABAIXO DESTA LINHA

for i in range( len(s)//2-1, -1, -1 ):
    s2 = s2 + chr( ord( s[i] )-1 )

for i in range( len(s)-1, len(s)//2-1, -1 ):
    s2 = s2 + chr( ord( s[i] )+1 )

# SEU CÓDIGO DEVE TERMINAR ACIMA DESTA LINHA
#-------------------------------------------------------------------

print('\nTexto', m, 'descriptografado:\n' )
print( s2 )


