cs = ['cddeef',
'Urfrydup`!ftylusmbnîuedpk!nepc!dmjkwhsmpg!`#9Q	b	s–b!OHnpqtupbtsd!edfr!sMàfsu!n.b!éWpbmnvlnfd!r:r!d.!`Dqp+ouspntc#`-!bFgedjhu`pscbd!Âruhj+dbs!n.c!`Tädpm!qQnbkv`mcp`-+!2o:`9q5`-!eqhâmhf/h!q6:p/tdFus`bk!dvn`bk!fwtfl{`!vbnnbt!rb`hvmmdirbs-d!rlvtfm!cenj>',
'C	mXpdxrj+o(`!mjco!gunivf!lX`jmoxe!s)hClpdcr!Elztmrbso*sgIdpxb!`nmbmonzm!sap`bkektr!nevktxu	!Abd!ennbqod!xsbgmdlx!&eqpdxoenCqfdgupdsqf!az`pmvm!ddcb>m	mS!gidjn`!mbr!vndbqo+@lIxpxe!qnhbdomzc!+tfhbrt!ankvntvuh!mb&!xhimjusfg!depvwhfm!ct	bSjgmdC`fmgrpvsdfq!thirf!atkmnfvfhqmt&!jhom!usigfd!tvbhomec@-',
"P`!qbcn`psq!`êm!bqnbqd-j	fNou`fl-n!qp!mbânnpsr!dê!`ckpdofeqp`tpb/nlOä`p!hjmoiwtfrksbh-æ!`o+äpl!`trf!rwdbo`hkmdpfsqj`b-b!noläp`!tufd!qpcs`hcvdm-i	bS/tcOnäpr!nnebqmdu+sbsutbc-n!obäqpé!+qssptdcvnsbd!rtofdvqt`!+josutfcsnftrttfotn-qso`ä-p	!'t0f!Bjnsqbì!mgsbhdnjrmn0f2o9u3f,-6!+oäMpU!Hh(v",
'Qdbosnbhcrêocth"r"rnO+äpd!mfstqrdvfftèdb!nef`!qwpftshjugnj+dbdsm!bpd!qdqbdcf`èbrmdirpr!âenp!dqsqp`hos`bnebn/q`E-']

print('Textos criptografados:')
for i in range(0,len(cs)):
    print('\nTexto %d:' % (i+1))
    print('---------')
    print( cs[i] )

print()
while True:
    m = int( input('Escolha o texto que deseja descriptografar (1..%d): ' % len(cs)))
    if m > 0 and m <= len(cs): break

s = cs[m-1]
s2 = ''

#-------------------------------------------------------------------
# SEU CÓDIGO DEVE INICIAR ABAIXO DESTA LINHA

for i in range( 0, len(s), 2 ):
    s2 = s2 + chr( ord( s[i] )-1 )

for i in range( 1, len(s), 2 ):
    s2 = s2 + chr( ord( s[i] )+1 )

# SEU CÓDIGO DEVE TERMINAR ACIMA DESTA LINHA
#-------------------------------------------------------------------

print('\nTexto', m, 'descriptografado:\n' )
print( s2 )


