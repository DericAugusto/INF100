cs = ['efeded',
'=ë"md.bpqlwns!wkâcuRct"rfqq!åcfUlv"r/_!"qscspemQka!v―Ã_"kcs!te;qjbv_ikofcjGjm"_!.tf$euc!qspvompfqpwEgp"eo/l!"gn;dv"!g_bop!w_fnntqtX*j"_e/b!"_ftjvgmrNp!"l-gcbfi"_mtbvcmhvrbu!q*bIgn"qvc!tc{cbfRw$_!"gbqcntfvxa!kbn_s"bFqmfr"/q*:fp6ï_!c/tchvqâzqqgc!"-qk5vm9za:g2V',
',gubfclCgguuz"m{cgpf!crtom"lmygbqcJ%!loAgppuocmoojb"`dc!"qfogikujp!"cunutnqvclne_!"twcfqfn{Rj"ugb!tlzqgohubgnDc!fxprpyiql!fge"om%bnl!cg-yut"mfpjZc`o@"qecgo"bv*tub!wlfoci"guup!fdocjqw!tkt"q{*fppfccmout"q!ylfq_iJtc!+ffpRscpn=g{bfFcC"ldlmq_jD`b*t"p!fcfptwkcpYpe"m!gdfjuvcj"pip%xkw!"cb)f!pruktycvqpnnm!D',
'\'!tG-rTb"Lèqjå*up5t"+v.2kc8ov1jc/!tbvq!nmncgpord"l!qëbåpsPmhAf0mc/bj&!nfw,ti_!trpqpä"mogn!uss"qpqnåmbpb!"sP.rc/k*st_pqpdncoinbpqscc!xb"megbsusb"rvqhå*!pèp"pä.aoc!lm-gbfxsuprokf"*nqcmåpjPddmb0qgq!umbqbsfsjpR!qfd,t"c!ëbp"_ätboqpoc-ctt"fq_t"t.kfgmsvafpug_okpjee!cctrjv"_fët"c!tqbqsoqvc_d"kpQ',
',fg_vdphcmfeds"uq_o"nft_!cp-epkcthtkmjtáegq!xqt"cjgqpfq"_fcEécgp/wpbscnuabgls"chqpå*sPmqt!#gpusepo!ëppd_icmtmbcèR']

print('Textos criptografados:')
for i in range(0,len(cs)):
    print('\nTexto %d:' % (i+1))
    print('---------')
    print( cs[i] )

print()
while True:
    m = int( input('Escolha o texto que deseja descriptografar (1..%d): ' % len(cs)))
    if m > 0 and m <= len(cs): break

s = cs[m-1]
s2 = ''

#-------------------------------------------------------------------
# SEU CÓDIGO DEVE INICIAR ABAIXO DESTA LINHA

for i in range( len(s)-1, -1, -3 ):
    s2 = s2 + chr( ord( s[i] )-2 )

for i in range( len(s)-2, -1, -3 ):
    s2 = s2 + chr( ord( s[i] )-1 )

for i in range( len(s)-3, -1, -3 ):
    s2 = s2 + chr( ord( s[i] )+2 )

# SEU CÓDIGO DEVE TERMINAR ACIMA DESTA LINHA
#-------------------------------------------------------------------

print('\nTexto', m, 'descriptografado:\n' )
print( s2 )


