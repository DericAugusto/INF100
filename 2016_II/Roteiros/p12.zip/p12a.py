cs = ['fghcba',
'ttf!b!vn!opwfmp!ef!mjoib;―!Qps!rvf!ftuâ!wpdë!dpn!fttf!bs-!upeb!difjb!ef!tj-!upeb!fospmbeb-!qbsb!gjohjs!rvf!wbmf!bmhvnb!dpvtb!oftuf!nvoep@hcdtp+`gktf``ltydu`lt`qD		-84-fào+3780+nkt`OnâR,`bhsÀ`qnshcD+!rnsmnB,8dltknU,qdKdcq`srnF`q`O!nquhkncncì`qswdnswdS',
"Zft-!boe!ipx!nboz!ujnft!nvtu!uif!dboopo!cbmmt!gmzCfgpsf!uifz(sf!gpsfwfs!cboofe@Uif!botxfs-!nz!gsjfoe-!jt!cmpxjo(!jo!uif!xjoeUif!botxfs!jt!cmpxjo(!jo!uif!xjoe/>cm`rdgsmhroddkrdgrdqnedA	kh`rduncdshgv`srtlr`drxm`lvnG	>m`l`lhgkk`btnxdqnedA	mvncjk`vm`l`srtlrc`nqxm`lvnG	(m`kxCanA'cmhVdgsmh&mhvnkA",
'bseb!sbodps/P!bnps!oäp!tf!bmfhsb!dpn!b!jokvtujèb-!nbt!tf!bmfhsb!dpn!b!wfsebef/Uvep!tpgsf-!uvep!dsë-!uvep!ftqfsb-!uvep!tvqpsub/)2!Dpsîoujpt!24;5.8-!OWJ*!tfnâm+dsmdlkhb`e`qhdrnâm	+rdrrdqdsmhrtdr`qtbnqonâm+`s`qsk`lnâM	-`gktfqndrnâm+`hqnkfm`udrnâm+`idumhnâM	-nrncmnaèqnl`n+dsmdhb`oèqnl`N',
'fqpjt!ejttp-!fousfhvf!p!bsrvjwp-!fodfssf!b!tfttäp!f!sbqb!gpsb/C	-`l`qfnqoncngk`æda`bnq`bhehqdudc`ædtprdnâM	  rmèa`q`O']

print('Textos criptografados:')
for i in range(0,len(cs)):
    print('\nTexto %d:' % (i+1))
    print('---------')
    print( cs[i] )

print()
while True:
    m = int( input('Escolha o texto que deseja descriptografar (1..%d): ' % len(cs)))
    if m > 0 and m <= len(cs): break

s = cs[m-1]
s2 = ''

#-------------------------------------------------------------------
# SEU CÓDIGO DEVE INICIAR ABAIXO DESTA LINHA

for i in range( len(s)-1, len(s)//2-1, -1 ):
    s2 = s2 + chr( ord( s[i] )+1 )

for i in range( 0, len(s)//2 ):
    s2 = s2 + chr( ord( s[i] )-1 )

# SEU CÓDIGO DEVE TERMINAR ACIMA DESTA LINHA
#-------------------------------------------------------------------

print('\nTexto', m, 'descriptografado:\n' )
print( s2 )


