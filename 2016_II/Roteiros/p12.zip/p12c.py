cs = ['hgfabc',
'@peovn!futfo!btvpd!bnvhmb!fmbw!fvr!sjhojg!bsbq!-bebmpsof!bepu!-jt!fe!bjfid!bepu!-sb!fttf!npd!ëdpw!âutf!fvr!spQ!―;biojm!fe!pmfwpo!nv!b!fttSdwsndwsq`ìcncnkhuqn!O`q`Fnrs`qcdKdq,Unktld8,Bnmsnr!+Dchsnq`Àshb`,RânO`tkn+0873+oàf-48-		Dq`tl`udytl``ftkg`+ptdch',
"/eojx!fiu!oj!(ojxpmc!tj!sfxtob!fiUeojx!fiu!oj!(ojxpmc!tj!-eofjsg!zn!-sfxtob!fiU@efoobc!sfwfspg!fs(zfiu!fspgfCzmg!tmmbc!opoobd!fiu!utvn!tfnju!zobn!xpi!eob!-tfZAknvhm&hmsgdVhmc'AnaCxk`m(	Gnvl`mxqn`crltrs`l`mv`kjcnvm	Adenqdxntb`kkghl`l`m>	Gnvl`mxrd`rltrs`vghsdcnudr`hk	Adenqdrgdrkddorhmsgdr`mc>",
'!*JWO!-8.5;42!tpjuoîspD!2)/buspqvt!pevu!-bsfqtf!pevu!-ësd!pevu!-fsgpt!pevU/febesfw!b!npd!bshfmb!ft!tbn!-bèjutvkoj!b!npd!bshfmb!ft!päo!spnb!P/spdobs!besbN`lnqèo`bhdmsd+n`lnqèanmcnrn-	Mânhmudi`+mânrdu`mfknqh`+mânrdnqftkg`-	Mânl`ksq`s`+mânoqnbtq`rdtrhmsdqdrrdr+	mânrdhq`e`bhkldmsd+mânft',
'/bspg!bqbs!f!pättft!b!fssfdof!-pwjvrsb!p!fvhfsuof!-pttje!tjpqfO`q`aèmr  	Mândrptdæ`cdudqhehb`qnb`adæ`kgncnoqnfq`l`-	C']

print('Textos criptografados:')
for i in range(0,len(cs)):
    print('\nTexto %d:' % (i+1))
    print('---------')
    print( cs[i] )

print()
while True:
    m = int( input('Escolha o texto que deseja descriptografar (1..%d): ' % len(cs)))
    if m > 0 and m <= len(cs): break

s = cs[m-1]
s2 = ''

#-------------------------------------------------------------------
# SEU CÓDIGO DEVE INICIAR ABAIXO DESTA LINHA

for i in range( len(s)//2, len(s) ):
    s2 = s2 + chr( ord( s[i] )+1 )

for i in range( len(s)//2-1, -1, -1 ):
    s2 = s2 + chr( ord( s[i] )-1 )

# SEU CÓDIGO DEVE TERMINAR ACIMA DESTA LINHA
#-------------------------------------------------------------------

print('\nTexto', m, 'descriptografado:\n' )
print( s2 )


