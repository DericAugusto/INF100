import math

soma = n = 0

while True:
    l = float( input('Entre com a largura (cm): '))
    if l < 0:
        print('Somente valores >= 0 são permitidos.')
    else: break
while True:
    h = float( input('Entre com a altura (cm): '))
    if h < 0:
        print('Somente valores >= 0 são permitidos.')
    else: break
while True:
    p = float( input('Entre com a profundidade (cm): '))
    if p < 0:
        print('Somente valores >= 0 são permitidos.')
    else: break

while l > 0 and h > 0 and p > 0:
    v = l * h * p
    print('Volume da caixa = %.2f cm3 = %.5f litros\n' % (v, v/1000) )
    soma = soma + v
    n = n + 1
    while True:
        l = float( input('Entre com a largura (cm): '))
        if l < 0:
            print('Somente valores >= 0 são permitidos.')
        else: break
    while True:
        h = float( input('Entre com a altura (cm): '))
        if h < 0:
            print('Somente valores >= 0 são permitidos.')
        else: break
    while True:
        p = float( input('Entre com a profundidade (cm): '))
        if p < 0:
            print('Somente valores >= 0 são permitidos.')
        else: break

if n > 0:
    media = soma/n
    print('\nMédia dos volumes = %.2f cm3 = %.5f litros' % (media, media/1000) )
