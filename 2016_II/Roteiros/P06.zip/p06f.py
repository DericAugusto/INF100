import math

soma = n = 0

while True:
    r = float( input('Entre com o raio do cone (cm): '))
    if r < 0:
        print('Somente valores >= 0 são permitidos.')
    else: break
while True:
    h = float( input('Entre com a altura do cone (cm): '))
    if h < 0:
        print('Somente valores >= 0 são permitidos.')
    else: break

while r > 0 and h > 0:
    v = math.pi * r**2 * h / 3
    print('Volume do cone = %.2f litros = %.3f galões\n' % (v*0.001, v*2.64e-4) )
    soma = soma + v
    n = n + 1
    while True:
        r = float( input('Entre com o raio do cone (cm): '))
        if r < 0:
            print('Somente valores >= 0 são permitidos.')
        else: break
    while True:
        h = float( input('Entre com a altura do cone (cm): '))
        if h < 0:
            print('Somente valores >= 0 são permitidos.')
        else: break

if n > 0:
    media = soma/n
    print('\nMédia dos volumes = %.2f litros = %.3f galões' % (media*0.001, media*2.64e-4) )
