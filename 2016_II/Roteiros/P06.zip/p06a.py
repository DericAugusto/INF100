import math

soma = n = 0

while True:
    r = float( input('Entre com o raio da lata (cm): '))
    if r < 0:
        print('Somente valores >= 0 são permitidos.')
    else: break
while True:
    h = float( input('Entre com a altura da lata (cm): '))
    if h < 0:
        print('Somente valores >= 0 são permitidos.')
    else: break

while r > 0 and h > 0:
    v = math.pi * r**2 * h
    print('Volume da lata = %.2f cm3 = %.5f litros\n' % (v, v/1000) )
    soma = soma + v
    n = n + 1
    while True:
        r = float( input('Entre com o raio da lata (cm): '))
        if r < 0:
            print('Somente valores >= 0 são permitidos.')
        else: break
    while True:
        h = float( input('Entre com a altura da lata (cm): '))
        if h < 0:
            print('Somente valores >= 0 são permitidos.')
        else: break

if n > 0:
    media = soma/n
    print('\nMédia dos volumes = %.2f cm3 = %.5f litros' % (media, media/1000) )
