n = int(input('Informe o numero de produtos: '))
meta = float(input('Informe a meta de vendas: '))

contagem = 0
total = 0.0

for i in range(1, n+1):
    preco = float(input('\nInforme o preço do produto %d: ' % i))
    qtd = int(input('Informe a quantidade de itens vendidos do produto %d: ' % i))

    venda = preco * qtd
    print('Valor total do produto %d: R$ %.2f' % (i, venda))

    if venda >= meta:
        contagem = contagem + 1
        total = total + venda

print('\n%d produtos atingiram a meta de vendas, totalizando %.2f reais em receita.' % (contagem, total))
