x = int( input('Digite um número inteiro: '))
m = int( input('Valor máximo a considerar: '))

print('\nMúltiplos de', x, 'entre 1 e', m, ':')
soma = soman = 0
for i in range( 1, m+1 ):
    if i % x == 0:
        print( i, end=', ')
        soma = soma + i
    else: soman = soman + i

print()
print('Soma dos múltiplos:         ', soma )
print('Soma dos NÃO múltiplos:     ', soman )
print('Relação entre as duas somas: %.3f' % (soma/soman) )
