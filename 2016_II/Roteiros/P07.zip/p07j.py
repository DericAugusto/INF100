n = int(input('Informe o número de alunos: '))
aulas = int(input('Informe o número de aulas dadas no semestre: '))

contagem = 0

for i in range(1, n+1):
    nota = float(input('\nInforme a nota final do aluno %d: ' % i))
    faltas = int(input('Informe o total de faltas do aluno %d: ' % i))

    percentual = faltas/aulas * 100

    if 40 <= nota < 60 and percentual <= 25:
        contagem = contagem + 1
        print('Este aluno ficou de Final.')
    else:
        print('Este aluno não ficou de Final.')

print('\n%d alunos (%.1f%%) ficaram de Final na turma.' % (contagem, contagem/n*100))
