n = int(input('Informe o numero de produtos: '))
meta = float(input('Informe a meta de vendas: '))

contagem = total = 0

for i in range(1, n+1):
    preco = float(input('\nInforme o preço do produto %d: ' % i))
    qtd = int(input('Informe a quantidade de itens vendidos do produto %d: ' % i))

    venda = preco * qtd
    print('Valor total do produto %d: R$ %.2f' % (i, venda))
    total = total + venda

    if venda < meta:
        contagem = contagem + 1

print('\nTotal em receita: %.2f' % total)
print('%d produtos (%.1f%%) não atingiram a meta de vendas.' % (contagem, contagem/n*100))
