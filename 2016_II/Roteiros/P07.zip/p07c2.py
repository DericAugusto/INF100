x = int( input('Digite um número inteiro: '))
m = int( input('Valor máximo a considerar: '))

print('\nMúltiplos de', x, 'entre 2 e', m, ':')
soma = 0
prod = 1
mx = m // x
for i in range( 1, mx+1 ):
    ix = i*x
    print( ix, end=', ')
    soma = soma + ix
    prod = prod * ix

print('\nSoma dos múltiplos:            ', soma )
print('Média aritmética dos múltiplos:', soma/mx )
print('Média geométrica dos múltiplos:', prod**(1/mx) )
