x = int( input('Digite um número inteiro: '))
m = int( input('Valor máximo a considerar: '))

print('\nMúltiplos de', x, 'entre 2 e', m, ':')
soma = n = 0
prod = 1
for i in range( 2, m+1 ):
    if i % x == 0:
        print( i, end=', ')
        soma = soma + i
        prod = prod * i
        n = n + 1

print('\nSoma dos múltiplos:            ', soma )
print('Média aritmética dos múltiplos:', soma/n )
print('Média geométrica dos múltiplos:', prod**(1/n) )
