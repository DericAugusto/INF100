n = int(input('Informe o número de alunos: '))
aulas = int(input('Informe o número de aulas dadas no semestre: '))

contagem = 0

for i in range(1, n+1):
    nota = float(input('\nInforme a nota final do aluno %d: ' % i))
    faltas = int(input('Informe o total de faltas do aluno %d: ' % i))

    percentual = faltas/aulas * 100

    if nota < 40 or percentual > 25:
        contagem = contagem + 1
        print('Este aluno foi reprovado.')
    else:
        print('Este aluno não foi reprovado.')

print('\n%d alunos estão reprovados na turma, num total de %d' % (contagem, n))
