n = int( input('Quantos convidados foram na festa? '))

cont = 0
for i in range( 1, n+1 ):
    peso = float(input('\nPeso do convidado %d (kg): ' % i))
    copos = int( input('Copos de 150ml de cerveja consumidos pelo convidado %d: ' % i))

    taxa = copos * 4.8 / (peso * 1.1)
    print('Taxa de alcoolemia: %.2f g/l' % taxa)

    if taxa < 0.2:
        cont = cont + 1

print('\n%d convidados apresentam taxa de alcoolemia abaixo de 0.2 g/l.' % cont)
