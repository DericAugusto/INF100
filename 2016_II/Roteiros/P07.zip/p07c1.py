x = int( input('Digite um número inteiro: '))
m = int( input('Valor máximo a considerar: '))

print('\nMúltiplos de', x, 'entre 2 e', m, ':')
soma = n = 0
prod = 1
x1 = x
while x <= m:
    print( x, end=', ')
    soma = soma + x
    prod = prod * x
    x = x + x1
    n = n + 1

print('\nSoma dos múltiplos:            ', soma )
print('Média aritmética dos múltiplos:', soma/n )
print('Média geométrica dos múltiplos:', prod**(1/n) )
