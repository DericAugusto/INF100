n = int(input('Informe o número de pacientes: '))

contagem = 0

for i in range(1, n+1):
    peso = float(input('\nInforme o peso do paciente %d (kg): ' % i))
    altura = float(input('Informe a altura do paciente %d (m): ' % i))
    imc = peso / altura**2
    print('IMC = %.3f kg/m²' % imc)

    if 18.5 <= imc <= 24.9:
        contagem = contagem + 1

print('\n%d pacientes estão no peso ideal (IMC entre 18.5 e 24.9).' % contagem)
