# Nome do aluno:
# Matrícula:
# Data:
# (breve comentário dizendo o programa faz)

import numpy as np

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# Ler um valor inteiro m (número de linhas da matriz).
# O programa só deve aceitar valores maiores que zero.
...

# Ler um valor inteiro n (número de colunas da matriz).
# O programa só deve aceitar valores maiores que zero.
...

# gerar matrizes A e B: m x n de valores inteiros aleatórios binários 0 ou 1
...

# Escrever as matrizes A e B na tela
...

# Calcular e escrever na tela a similaridade entre A e B
...
