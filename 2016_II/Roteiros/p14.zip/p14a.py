import numpy as np

np.random.seed(0)

# Ler o valor de m
while True:
    m = int( input('Entre com o número de linhas da matriz: '))
    if m <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# Ler o valor de n
while True:
    n = int( input('Entre com o número de colunas da matriz: '))
    if n <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# gerar matriz A: m x n de valores inteiros aleatórios entre 1 e 10
A = np.random.randint( 1, 11, (m, n) )

# Escrever a matriz A na tela e guardar o menor valor
print('\nMatriz A:')
menor = A[0][0]
for i in range(0, m):
    for j in range(0, n):
        print('%4d' % A[i][j], end='')
        if A[i][j] < menor: menor = A[i][j]
    print()
    
print('\nMenor valor:', menor)

# Mostrar posições da matriz onde ocorre o menor valor
print('\nPosições de ocorrência do valor %d:' % menor )
print('\nLinha   Coluna')
print('--------------')
for i in range(0, m):
    for j in range(0, n):
        if A[i][j] == menor:
            print('%3d%8d' % (i, j))
