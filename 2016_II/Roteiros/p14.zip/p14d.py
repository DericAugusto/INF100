import numpy as np

np.random.seed(0)

# Ler o valor de m
while True:
    m = int( input('Entre com o número de linhas da matriz: '))
    if m <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# Ler o valor de n
while True:
    n = int( input('Entre com o número de colunas da matriz: '))
    if n <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# gerar matrizes A e B: m x n de valores inteiros aleatórios binários 0 ou 1
A = np.random.randint( 0, 2, (m, n) )
B = np.random.randint( 0, 2, (m, n) )

# Escrever as matrizes A e B na tela
print('\nMatriz A:')
for i in range(0, m):
    for j in range(0, n):
        print('%5d' % A[i][j], end='')
    print()

print('\nMatriz B:')
for i in range(0, m):
    for j in range(0, n):
        print('%5d' % B[i][j], end='')
    print()

# Calcular e escrever na tela a similaridade entre A e B
iguais = 0
for i in range(0, m):
    for j in range(0, n):
        if A[i][j] == B[i][j]: iguais = iguais + 1
simil = iguais / (m*n)
print('\nSimilaridade entre A e B: %.4f = %.2f%%' % (simil, simil*100) )
