# Nome do aluno:
# Matrícula:
# Data:
# (breve comentário dizendo o programa faz)

import numpy as np

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# Ler um valor inteiro m (número de linhas da matriz).
# O programa só deve aceitar valores maiores que zero.
...

# Ler um valor inteiro n (número de colunas da matriz).
# O programa só deve aceitar valores maiores que zero.
...

# Criar uma matriz A: m x n de valores inteiros aleatórios entre 1 e 10.
...

# Escrever a matriz A na tela e guardar o menor valor
...

# Mostrar o menor valor na tela e as posições da matriz onde ele ocorre
...
