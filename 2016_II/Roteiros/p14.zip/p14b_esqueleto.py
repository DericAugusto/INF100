# Nome do aluno:
# Matrícula:
# Data:
# (breve comentário dizendo o programa faz)

import numpy as np

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# Ler um valor inteiro m (número de linhas da matriz).
# O programa só deve aceitar valores maiores que zero.
...

# Ler um valor inteiro n (número de colunas da matriz).
# O programa só deve aceitar valores maiores que zero.
...

# gerar matriz A: m x n de valores reais aleatórios distribuídos
# uniformemente no intervalo aberto [0,250)
...

# Escrever a matriz A na tela e encontrar o maior valor
...
    
# Normalizar a matriz A e escrevê-la na tela
...
    
