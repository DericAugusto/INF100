# Nome do aluno:
# Matrícula:
# Data:
# (breve comentário dizendo o programa faz)

import numpy as np

# iniciar o gerador de números aleatórios de modo que os valores
# sejam os mesmos sempre que o programa for executado.
np.random.seed(0)

# Ler um valor inteiro m (número de linhas da matriz).
# O programa só deve aceitar valores maiores que zero.
...

# Ler um valor inteiro n (número de colunas da matriz).
# O programa só deve aceitar valores maiores que zero.
...

# gerar matriz A: m x n de valores reais uniformemente
# distribuídos no intervalo aberto [1,10)
...

# Escrever a matriz A na tela
...

# Para o passo seguinte você pode escolher UMA das seguintes abordagens:

### Abordagem 1: ###
# Criar um arranjo M de m itens e guardar o maior valor de cada linha
# nesse arranjo.
...
    
# Dividir cada elemento A[i][j] por M[i] e escrever o resultado na tela 
...

### Abordagem 2: ###
# Para cada linha i da matriz A:
#     Determinar maior = maior valor da linha i
#     Dividir todos os elementos da linha i por maior.
...
    
# Escrever a matriz A na tela 
...
