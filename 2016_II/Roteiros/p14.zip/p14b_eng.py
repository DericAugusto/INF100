import numpy as np

np.random.seed(0)

# Read an integer value m (number of rows in the matrix).
# The program must only accept values greater than zero.
while True:
    m = int( input('Enter the number of rows in the matrix: '))
    if m <= 0:
        print('Value must be greater than zero.')
    else: break

# Read an integer value n (number of columns in the matrix).
# The program must only accept values greater than zero.
while True:
    n = int( input('Enter the number of columns in the matrix: '))
    if n <= 0:
        print('Value must be greater than zero.')
    else: break

# Generate the matrix A: m x n of random real values distributed
# in a uniform manner in the open interval [0,250).
A = np.random.uniform( 0, 250, (m, n) )

# Write matrix A on screen and find its biggest value.
print('\nMatrix A:')
highest = A[0][0]
for i in range(0, m):
    for j in range(0, n):
        print('%7.1f' % A[i][j], end='')
        if A[i][j] > highest: highest = A[i][j]
    print()
    
print('\nHighest value: %.1f' % highest)

# Normalize matrix A and write it on screen.
A = A / highest
print('\nMatrix A normalizada:')
for i in range(0, m):
    for j in range(0, n):
        print('%7.3f' % A[i][j], end='')
    print()
    
