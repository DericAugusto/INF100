import numpy as np

np.random.seed(0)

# Ler o valor de m
while True:
    m = int( input('Entre com o número de linhas da matriz: '))
    if m <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# Ler o valor de n
while True:
    n = int( input('Entre com o número de colunas da matriz: '))
    if n <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# gerar matrizes A e B: (m x n) de valores inteiros aleatórios binários 0 ou 1
A = np.random.randint( 0, 2, (m, n) )
B = np.random.randint( 0, 2, (m, n) )

# Escrever as matrizes A e B na tela, calculando a esparsidade de cada uma
nulos = 0
print('\nMatriz A:')
for i in range(0, m):
    for j in range(0, n):
        print('%5d' % A[i][j], end='')
        if A[i][j] == 0: nulos = nulos + 1
    print()
espA = nulos / (m*n)
print('Esparsidade: %.4f = %.2f%%' % (espA, espA*100) )

nulos = 0
print('\nMatriz B:')
for i in range(0, m):
    for j in range(0, n):
        print('%5d' % B[i][j], end='')
        if B[i][j] == 0: nulos = nulos + 1
    print()
espB = nulos / (m*n)
print('Esparsidade: %.4f = %.2f%%' % (espB, espB*100) )

# Escrever a diferença entre as duas esparsidades
print('\nEsparsidade de A – Esparsidade de B = %.4f' % (espA-espB) )
