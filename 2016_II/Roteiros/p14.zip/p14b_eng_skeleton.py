# Student name:
# ID number:
# Date:
# (a short comment about what the program does)

import numpy as np

# start the random number generator so that the values
# are the same every time the program is executed.
np.random.seed(0)

# Read an integer value m (number of rows in the matrix).
# The program must only accept values greater than zero.
...

# Read an integer value n (number of columns in the matrix).
# The program must only accept values greater than zero.
...

# Generate the matrix A: m x n of random real values distributed
# in a uniform manner in the open interval [0,250).
...

# Write matrix A on screen and find its biggest value.
...

# Normalize matrix A and write it on screen.
...
    
