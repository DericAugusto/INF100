import numpy as np

np.random.seed(0)

# Ler o valor de m
while True:
    m = int( input('Entre com o número de linhas da matriz: '))
    if m <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# Ler o valor de n
while True:
    n = int( input('Entre com o número de colunas da matriz: '))
    if n <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# gerar matriz A: m x n de valores reais uniformemente
# distribuídos no intervalo aberto [1,10)
A = np.random.uniform( 1, 10, (m, n) )

# Escrever a matriz A na tela
print('\nMatriz A:')
for i in range(0, m):
    for j in range(0, n):
        print('%5.0f' % A[i][j], end='')
    print()
    
# Criar um arranjo M de m itens e guardar o maior valor de cada linha
# nesse arranjo.
M = np.empty( m )
for i in range(0, m):
    maior = A[i][0]
    for j in range(0, n):
        if A[i][j] > maior: maior = A[i][j]
    M[i] = maior
    
# Dividir cada elemento A[i][j] por M[i] e escrever o resultado na tela 
print('\nMatriz A normalizada por linha:')
for i in range(0, m):
    for j in range(0, n):
        A[i][j] = A[i][j] / M[i]
        print('%7.3f' % A[i][j], end='')
    print()
