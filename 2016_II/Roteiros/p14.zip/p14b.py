import numpy as np

np.random.seed(0)

# Ler o valor de m
while True:
    m = int( input('Entre com o número de linhas da matriz: '))
    if m <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# Ler o valor de n
while True:
    n = int( input('Entre com o número de colunas da matriz: '))
    if n <= 0:
        print('Valor deve ser maior que zero.')
    else: break

# gerar matriz A: m x n de valores reais aleatórios distribuídos
# uniformemente no intervalo aberto [0,250)
A = np.random.uniform( 0, 250, (m, n) )

# Escrever a matriz A e encontrar o maior valor
print('\nMatriz A:')
maior = A[0][0]
for i in range(0, m):
    for j in range(0, n):
        print('%7.1f' % A[i][j], end='')
        if A[i][j] > maior: maior = A[i][j]
    print()
    
print('\nMaior valor: %.1f' % maior)

# Normalizar a matriz A e escrevê-la na tela
A = A / maior
print('\nMatriz A normalizada:')
for i in range(0, m):
    for j in range(0, n):
        print('%7.3f' % A[i][j], end='')
    print()
    
