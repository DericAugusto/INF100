import numpy as np
import random

#-------------------------------------------------------------------
# Início da montagem dos dados de simulação - Não alterar esta parte

random.seed()

while True:
    n = int( input('Informe o número de dias da simulação: '))
    if n > 0: break

Tmin = np.empty( n )
Tmax = np.empty( n )

for i in range(0, n):
    # sorteia Tmin entre 1.2 e 17.9
    Tmin[i] = round( random.random() * (17.9 - 1.2) + 1.2, 1 )
    # sorteia Tmax entre 23.5 e 37.6
    Tmax[i] = round( random.random() * (37.6 - 23.5) + 23.5, 1 )

# Final da montagem dos dados de simulação - Não alterar esta parte
#-------------------------------------------------------------------

# Cálculo de Tmed e cálculo das médias globais
Tmed = np.empty( n )
s1 = s2 = s3 = 0  # somas
gmin = 100
gmax = -1
for i in range(0, n):
    Tmed[i] = (Tmin[i] + Tmax[i]) / 2
    s1 = s1 + Tmin[i]
    s2 = s2 + Tmed[i]
    s3 = s3 + Tmax[i]
    if Tmin[i] < gmin: gmin = Tmin[i]
    if Tmax[i] > gmax: gmax = Tmax[i]
m1 = s1 / n
m2 = s2 / n
m3 = s3 / n

# Impressão da tabela
print('\nDia   Tmin (°C)   Tmed (°C)   Tmax (°C)')
for i in range(0, n):
    print('%3d%9.1f%12.1f%12.1f' % (i+1, Tmin[i], Tmed[i], Tmax[i]))

# Impressão dos outros resultados
print()
print('Temperatura mínima global:             %4.1f' % gmin )
print('Temperatura máxima global:             %4.1f' % gmax )
print('Média global das temperaturas mínimas: %4.1f' % m1 )
print('Média global das temperaturas médias:  %4.1f' % m2 )
print('Média global das temperaturas máximas: %4.1f' % m3 )
